#Ubertooth manuals

These files are generated from the markdown documentation in the parent
directory. In general you should avoid modify these files as modifications
will be overwritten.

Please make modifications to the markdown files in the parent directory.

To build these files use markdown2man, go-md2man, or ronn.
