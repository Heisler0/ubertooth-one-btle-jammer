# All files in the 'lib' directory will be loaded
# before nanoc starts compiling.
